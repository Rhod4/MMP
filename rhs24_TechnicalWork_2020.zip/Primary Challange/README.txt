Primary Challenge Read me file.
This read me contains information about how to view the site and the structure of the website.

To view the website go to;
https://users.aber.ac.uk/rhs24/MMP/LoginPage/index.php

GitHub link;
https://users.aber.ac.uk/rhs24/MMP/LoginPage/index.php 

Connection folder:
This is the database folder, it holds the information that is needed for the database connection
The file also contains the logout code for the website

GamePage folder:
This is the folder that stores the GamePage of the website, e.g. the page that contains the game
This file also conatins the JavaScript file and the CSS file for the game

LoginPage folder:
This contains the LoginPage for the website, e.g. where the user logs in.
This folder also contains the login file and and the CSS for the login screen

MainCSS folder:
Where the CSS document that contains information for multiple pages are kept, e.g. Topbar and footer deatils

StaffPage folder:
Contains the staff/admin page for the website, e.g. file with the table in it.
This folder also contains the CSS file for the staff/admin page